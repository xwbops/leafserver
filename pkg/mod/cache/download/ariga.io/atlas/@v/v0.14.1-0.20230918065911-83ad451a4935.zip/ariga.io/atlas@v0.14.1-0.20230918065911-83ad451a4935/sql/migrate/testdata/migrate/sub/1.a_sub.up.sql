-- create table "t_sub"
CREATE TABLE t_sub(c int);
-- add c1 column
ALTER TABLE t_sub ADD c1 int;