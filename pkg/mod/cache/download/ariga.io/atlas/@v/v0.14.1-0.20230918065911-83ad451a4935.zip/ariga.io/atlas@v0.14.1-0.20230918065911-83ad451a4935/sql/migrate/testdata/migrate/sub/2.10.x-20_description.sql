-- add c2 column
ALTER TABLE t_sub ADD c2 int;